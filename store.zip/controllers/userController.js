const Product = require('../models/product');
const User = require('../models/user');

exports.getSellerDashboard = async (req, res) => {
  try {
    // Contoh: tampilkan info user, statistik sederhana
    const user = await User.findById(req.session.userId);
    res.render('user/dashboard', { title: 'Seller Dashboard', user, message: null });
  } catch (err) {
    console.error(err);
    res.render('user/dashboard', { title: 'Seller Dashboard', user: null, message: 'Error loading dashboard' });
  }
};

exports.getMyProducts = async (req, res) => {
  try {
    const products = await Product.find({ seller: req.session.userId }).sort({ createdAt: -1 });
    res.render('user/my_products', { title: 'My Products', products, message: null });
  } catch (err) {
    console.error(err);
    res.render('user/my_products', { title: 'My Products', products: [], message: 'Error fetching your products' });
  }
};