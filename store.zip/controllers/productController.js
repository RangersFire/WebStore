const Product = require('../models/product');
const cloudinary = require('../config/cloudinary');
const fs = require('fs');
const path = require('path');

exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find({ status: 'approved' }).populate('seller', 'username whatsappNumber');
    res.render('products/index', { title: 'All Products', products, message: null });
  } catch (err) {
    console.error(err);
    res.render('products/index', { title: 'All Products', products: [], message: 'Error fetching products' });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('seller', 'username whatsappNumber');
    if (!product || product.status !== 'approved') {
      // req.flash('error', 'Product not found or not approved');
      return res.redirect('/products');
    }
    const waMessage = encodeURIComponent(`Halo ${product.seller.username}, saya tertarik dengan produk Anda "${product.name}" yang ada di marketplace.`);
    const whatsappLink = `https://wa.me/${product.seller.whatsappNumber}?text=${waMessage}`;
    res.render('products/show', { title: product.name, product, whatsappLink, message: null });
  } catch (err) {
    console.error(err);
    // req.flash('error', 'Error fetching product');
    res.redirect('/products');
  }
};

exports.getNewProductForm = (req, res) => {
  res.render('products/new', { title: 'Add New Product', message: null });
};

exports.createProduct = async (req, res) => {
  const { name, description, price, category } = req.body;
  if (!req.file) {
    return res.render('products/new', { title: 'Add New Product', message: 'Product image is required' });
  }

  try {
    const result = await cloudinary.uploader.upload(req.file.path, {
      folder: 'my_marketplace_products',
      // public_id: `product_${Date.now()}` // Opsional, untuk nama file unik
    });

    fs.unlinkSync(req.file.path); // Hapus file dari server setelah upload ke Cloudinary

    const product = new Product({
      name,
      description,
      price,
      category,
      imageUrl: result.secure_url,
      seller: req.session.userId,
      status: 'pending', // Produk baru perlu approval admin
    });

    await product.save();
    // req.flash('success', 'Product submitted for approval!');
    res.redirect('/user/my-products');
  } catch (err) {
    console.error(err);
    if (req.file && req.file.path) { // Jika error setelah upload file, coba hapus file temp
        try { fs.unlinkSync(req.file.path); } catch (e) { console.error("Error deleting temp file:", e); }
    }
    res.render('products/new', { title: 'Add New Product', message: 'Error creating product' });
  }
};