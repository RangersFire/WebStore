const User = require('../models/user');

exports.isLoggedIn = (req, res, next) => {
  if (req.session.userId) {
    return next();
  }
  // req.flash('error', 'You must be signed in first!'); // Jika menggunakan connect-flash
  res.redirect('/auth/login');
};

exports.isSeller = async (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  const user = await User.findById(req.session.userId);
  if (user && (user.role === 'seller' || user.role === 'admin') && !user.isBanned) {
    return next();
  }
  // req.flash('error', 'You do not have permission to perform this action.');
  res.redirect('/');
};

exports.isAdmin = async (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/auth/login');
  }
  const user = await User.findById(req.session.userId);
  if (user && user.role === 'admin' && !user.isBanned) {
    return next();
  }
  // req.flash('error', 'You do not have permission to perform this action.');
  res.redirect('/');
};

exports.isNotBanned = async (req, res, next) => {
  if (req.session.userId) {
    const user = await User.findById(req.session.userId);
    if (user && user.isBanned) {
      req.session.destroy();
      // req.flash('error', 'Your account has been banned.');
      return res.redirect('/auth/login');
    }
  }
  next();
};