const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { isLoggedIn, isSeller, isNotBanned } = require('../middleware/authMiddleware');
router.get('/dashboard', isLoggedIn, isSeller, isNotBanned, userController.getSellerDashboard);
router.get('/my-products', isLoggedIn, isSeller, isNotBanned, userController.getMyProducts);

module.exports = router;