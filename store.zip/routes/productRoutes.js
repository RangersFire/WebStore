const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { isLoggedIn, isSeller, isNotBanned } = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

router.get('/', productController.getAllProducts);
router.get('/new', isLoggedIn, isSeller, isNotBanned, productController.getNewProductForm);
router.post('/', isLoggedIn, isSeller, isNotBanned, upload.single('productImage'), productController.createProduct);
router.get('/:id', productController.getProductById);

module.exports = router;